import { Component, MutableRefObject, ReactNode, Suspense, useEffect, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Billboard, Sparkles, Text, useGLTF } from '@react-three/drei';
import { GroupProps } from '@react-three/fiber';
import * as THREE from 'three';
import { Product } from '../../lib/types';
import garmentRackUrl from '../../assets/models/garment-rack.glb';
import haloChandelierUrl from '../../assets/models/halo-chandelier.glb';
import planterUrl from '../../assets/models/planter.glb';
import roomShellUrl from '../../assets/models/pink-halo-room-shell.glb';
import displayPlatformUrl from '../../assets/models/pink-halo-display-platform.glb';
import shopCounterUrl from '../../assets/models/pink-halo-counter.glb';
import mirrorWallUrl from '../../assets/models/pink-halo-mirror.glb';
import saleShelvesUrl from '../../assets/models/pink-halo-sale-shelves.glb';
import loungeUrl from '../../assets/models/pink-halo-lounge.glb';
import accessoriesUrl from '../../assets/models/pink-halo-accessories.glb';
import piggybankUrl from '../../assets/models/pink-halo-piggybank.glb';
import lightingUrl from '../../assets/models/pink-halo-lighting.glb';
import fxUrl from '../../assets/models/pink-halo-fx.glb';
import shopkeeperUrl from '../../assets/models/pink-halo-shopkeeper.glb';

useGLTF.preload(garmentRackUrl);
useGLTF.preload(haloChandelierUrl);
useGLTF.preload(planterUrl);
useGLTF.preload(roomShellUrl);
useGLTF.preload(displayPlatformUrl);
useGLTF.preload(shopCounterUrl);
useGLTF.preload(mirrorWallUrl);
useGLTF.preload(saleShelvesUrl);
useGLTF.preload(loungeUrl);
useGLTF.preload(accessoriesUrl);
useGLTF.preload(piggybankUrl);
useGLTF.preload(lightingUrl);
useGLTF.preload(fxUrl);
useGLTF.preload(shopkeeperUrl);

function LoadedModel({ url, ...props }: { url: string } & GroupProps) {
  const { scene } = useGLTF(url);
  const instance = useMemo(() => scene.clone(true), [scene]);
  return <primitive object={instance} {...props} />;
}

class ModelErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() { return this.state.failed ? null : this.props.children; }
}

function ModeledFixture(props: { url: string } & GroupProps) {
  return <ModelErrorBoundary><Suspense fallback={null}><LoadedModel {...props} /></Suspense></ModelErrorBoundary>;
}

export interface TouchMovement { forward: boolean; backward: boolean; left: boolean; right: boolean; }

type NpcDefinition = {
  id: string;
  label: string;
  category: Product['category'] | 'All';
  position: [number, number, number];
  color: string;
};

const SHOPKEEPER: NpcDefinition = {
  id: 'npc-shopkeeper',
  label: 'Shopkeeper',
  category: 'All',
  position: [-0.35, 0, 1.2],
  color: '#ff9fc4',
};

const NPCS: NpcDefinition[] = [SHOPKEEPER];

const DONATION_PIG_POSITION: [number, number, number] = [2.35, 0, -2.45];
const PLAYER_RADIUS = 0.32;
const ROOM_LABEL = 'Pink Halo Shop';

type BoxCollider = { minX: number; maxX: number; minZ: number; maxZ: number };

function boxCollider(x: number, z: number, width: number, depth: number): BoxCollider {
  return { minX: x - width / 2, maxX: x + width / 2, minZ: z - depth / 2, maxZ: z + depth / 2 };
}

const STORE_COLLIDERS: BoxCollider[] = [
  boxCollider(0, 4.95, 8.1, 0.28),
  boxCollider(-4.0, 0, 0.28, 10.1),
  boxCollider(4.0, 0, 0.28, 10.1),
  boxCollider(-2.45, -5.0, 3.1, 0.28),
  boxCollider(2.45, -5.0, 3.1, 0.28),
  boxCollider(0, 2.55, 2.9, 1.1),
  boxCollider(-2.25, 0.85, 2.2, 0.75),
  boxCollider(-1.75, -3.58, 3.25, 0.95),
  boxCollider(1.55, -3.35, 1.75, 1.0),
  boxCollider(3.55, -1.6, 0.5, 1.3),
  boxCollider(-3.55, 4.2, 0.75, 0.75),
  boxCollider(3.45, 4.0, 0.75, 0.75),
  boxCollider(-3.55, -2.25, 0.75, 0.75),
  boxCollider(3.4, -3.15, 0.75, 0.75),
  boxCollider(DONATION_PIG_POSITION[0], DONATION_PIG_POSITION[2], 1.0, 0.85),
];

function BillboardText({ children, position, color = '#fff4f8', fontSize = 0.12, maxWidth, letterSpacing }: {
  children: ReactNode;
  position: [number, number, number];
  color?: string;
  fontSize?: number;
  maxWidth?: number;
  letterSpacing?: number;
}) {
  return (
    <Billboard position={position} follow>
      <Text fontSize={fontSize} color={color} anchorX="center" anchorY="middle" maxWidth={maxWidth} textAlign="center" letterSpacing={letterSpacing}>
        {children}
      </Text>
    </Billboard>
  );
}

function circleIntersectsBox(x: number, z: number, radius: number, box: BoxCollider): boolean {
  const closestX = THREE.MathUtils.clamp(x, box.minX, box.maxX);
  const closestZ = THREE.MathUtils.clamp(z, box.minZ, box.maxZ);
  const dx = x - closestX;
  const dz = z - closestZ;
  return dx * dx + dz * dz < radius * radius;
}

function playerPositionBlocked(x: number, z: number): boolean {
  if (x < -4.7 || x > 4.7 || z < -5.9 || z > 5.9) return true;
  if (STORE_COLLIDERS.some(collider => circleIntersectsBox(x, z, PLAYER_RADIUS, collider))) return true;

  const dx = x - SHOPKEEPER.position[0];
  const dz = z - SHOPKEEPER.position[2];
  const combinedRadius = PLAYER_RADIUS + 0.34;
  if (dx * dx + dz * dz < combinedRadius * combinedRadius) return true;

  return false;
}

function GarmentPreview({ position, products, color }: { position: [number, number, number]; products: Product[]; color: string }) {
  const visible = products.slice(0, 6);
  if (!visible.length) return null;

  return (
    <group position={position}>
      {visible.map((product, index) => (
        <group key={product.id} position={[0, 0, (index - (visible.length - 1) / 2) * 0.22]}>
          <mesh position={[0, 1.36, 0]}>
            <boxGeometry args={[0.08, 0.5, 0.16]} />
            <meshStandardMaterial color={index % 2 ? color : '#fff0f6'} roughness={0.64} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function ShopkeeperMarker({ inputMode }: { inputMode: 'keyboard' | 'gamepad' }) {
  const actionText = inputMode === 'gamepad' ? 'Press X or click to shop' : 'Press E or click to shop';
  return (
    <group position={SHOPKEEPER.position}>
      <ModeledFixture url={shopkeeperUrl} scale={0.92} rotation={[0, Math.PI, 0]} />
      <BillboardText position={[0, 2.15, 0]} fontSize={0.12} maxWidth={1.4}>{SHOPKEEPER.label}</BillboardText>
      <BillboardText position={[0, 1.95, 0]} fontSize={0.09} color={SHOPKEEPER.color}>{actionText}</BillboardText>
      <pointLight position={[0, 1.7, 0]} intensity={8} distance={2.7} color={SHOPKEEPER.color} />
    </group>
  );
}

function DonationPig({ inputMode }: { inputMode: 'keyboard' | 'gamepad' }) {
  const actionText = inputMode === 'gamepad' ? 'Press X or click to donate' : 'Press E or click to donate';
  return (
    <group position={DONATION_PIG_POSITION}>
      <ModeledFixture url={piggybankUrl} scale={0.92} rotation={[0, Math.PI, 0]} />
      <BillboardText position={[0, 1.6, 0]} fontSize={0.12}>DONATION PIGGY BANK</BillboardText>
      <BillboardText position={[0, 1.4, 0]} fontSize={0.085} color="#ffc7dc">{actionText}</BillboardText>
      <pointLight position={[0, 1.1, 0]} intensity={7} distance={3} color="#ff9fc4" />
    </group>
  );
}

function NeonLabel({ position, text, size = 0.14, color = '#ff83c2' }: { position: [number, number, number]; text: string; size?: number; color?: string }) {
  return (
    <Billboard position={position} follow>
      <Text fontSize={size} color={color} anchorX="center" anchorY="middle" maxWidth={1.6} textAlign="center" letterSpacing={0.08}>
        {text}
      </Text>
    </Billboard>
  );
}

function ShopRoom({ products, inputMode }: { products: Product[]; inputMode: 'keyboard' | 'gamepad' }) {
  const byCategory = (category: Product['category']) => products.filter(product => product.category === category);

  return (
    <group>
      <ModeledFixture url={roomShellUrl} />
      <ModeledFixture url={shopCounterUrl} />
      <ModeledFixture url={saleShelvesUrl} />
      <ModeledFixture url={mirrorWallUrl} />
      <ModeledFixture url={garmentRackUrl} />
      <ModeledFixture url={loungeUrl} />
      <ModeledFixture url={displayPlatformUrl} />
      <ModeledFixture url={accessoriesUrl} />
      <ModeledFixture url={piggybankUrl} />
      <ModeledFixture url={lightingUrl} />
      <ModeledFixture url={fxUrl} />
      <ModeledFixture url={planterUrl} />
      <ModeledFixture url={haloChandelierUrl} />
      <GarmentPreview position={[-2.25, 0, 0.9]} products={[...byCategory('Dresses'), ...byCategory('Tops')]} color="#ff5fa2" />
      <GarmentPreview position={[1.95, 0, 3.72]} products={byCategory('Accessories')} color="#f4c27a" />
      <NeonLabel position={[-3.05, 2.1, 1.85]} text="PINK HALO" size={0.24} />
      <NeonLabel position={[3.7, 2.1, 1.1]} text="YOU LOOK GOOD IN PINK" size={0.11} />
      <NeonLabel position={[0.3, 1.65, -2.15]} text="WELCOME TO PINK HALO" size={0.1} color="#ffd6e8" />
      <ShopkeeperMarker inputMode={inputMode} />
      <DonationPig inputMode={inputMode} />
      <Sparkles position={[0, 2.15, -0.2]} count={24} scale={2.8} size={0.68} speed={0.17} color="#ff93d1" />
      <Sparkles position={[2.15, 1.8, 2.0]} count={14} scale={1.1} size={0.45} speed={0.12} color="#ff5fa2" />
      <pointLight position={[0, 3.2, -0.5]} intensity={13} distance={5.2} color="#ff7dc9" />
      <pointLight position={[-3.35, 2.2, 1.2]} intensity={9.5} distance={4.8} color="#ff73d8" />
      <pointLight position={[3.55, 2.05, 1.25]} intensity={10} distance={4.8} color="#ff5fa2" />
    </group>
  );
}

function roomAt(x: number, z: number): string | null {
  if (z < -2.2) return 'Pink Halo Lounge';
  if (z > 1.85) return 'Shop Counter';
  if (x < -1.15) return 'Clothing Rack';
  if (x > 1.3) return 'Mirror Wall';
  return ROOM_LABEL;
}

function Player({ active, movement, initialPosition, onRoomChange, onExitChange, onNpcFocus, onNpcInteract, onDonationFocus, onDonationInteract, onPlayerPosition, onFootstep, onStep, onInputModeChange }: Omit<PinkHaloSceneProps, 'products'>) {
  const { camera, gl } = useThree();
  const keys = useRef<Record<string, boolean>>({});
  const yaw = useRef(Math.PI);
  const pitch = useRef(0);
  const currentRoom = useRef<string | null>(null);
  const atExit = useRef(false);
  const elapsed = useRef(0);
  const touchPoint = useRef<{ x: number; y: number } | null>(null);
  const focusedNpc = useRef<string | null>(null);
  const donationFocused = useRef(false);
  const positionReportElapsed = useRef(0);
  const stepDistance = useRef(0);
  const jumpVelocity = useRef(0);
  const grounded = useRef(true);
  const lastInputMode = useRef<'keyboard' | 'gamepad'>('keyboard');
  const lastGamepadButtons = useRef<Record<number, boolean>>({});
  const setInputMode = (mode: 'keyboard' | 'gamepad') => {
    if (lastInputMode.current !== mode) {
      lastInputMode.current = mode;
      onInputModeChange?.(mode);
    }
  };
  useEffect(() => {
    camera.position.set(initialPosition?.x ?? 0, 1.65, initialPosition?.z ?? 4.2);
    camera.rotation.order = 'YXZ';
  }, [camera, initialPosition?.x, initialPosition?.z]);

  useEffect(() => {
    if (!active) return;
    const canvas = gl.domElement;
    const down = (event: KeyboardEvent) => { keys.current[event.code] = true; };
    const up = (event: KeyboardEvent) => { keys.current[event.code] = false; };
    let dragging = false;
    let dragPoint: { x: number; y: number } | null = null;
    const dragStart = (event: PointerEvent) => {
      if (event.pointerType !== 'mouse' || event.button !== 0 || document.pointerLockElement === canvas) return;
      dragging = true;
      dragPoint = { x: event.clientX, y: event.clientY };
      canvas.setPointerCapture?.(event.pointerId);
    };
    const dragLook = (event: PointerEvent) => {
      if (!dragging || !dragPoint) return;
      yaw.current -= (event.clientX - dragPoint.x) * 0.004;
      pitch.current = THREE.MathUtils.clamp(pitch.current - (event.clientY - dragPoint.y) * 0.003, -1.15, 1.15);
      dragPoint = { x: event.clientX, y: event.clientY };
    };
    const dragEnd = () => { dragging = false; dragPoint = null; };
    const lockedLook = (event: MouseEvent) => {
      if (document.pointerLockElement !== canvas) return;
      yaw.current -= event.movementX * 0.0018;
      pitch.current = THREE.MathUtils.clamp(pitch.current - event.movementY * 0.0015, -1.15, 1.15);
    };
    const requestLock = () => {
      if (document.pointerLockElement !== canvas) canvas.requestPointerLock?.();
    };

    const interact = (event: KeyboardEvent) => {
      setInputMode('keyboard');
      if (event.code === 'Space' && grounded.current) {
        jumpVelocity.current = 4.6;
        grounded.current = false;
        return;
      }
      if (event.code !== 'KeyE') return;
      if (donationFocused.current) { onDonationInteract(); return; }
      if (focusedNpc.current) {
        const npc = NPCS.find(item => item.id === focusedNpc.current);
        if (npc) onNpcInteract(npc.category, npc.label);
      }
    };

    let lookTouchId: number | null = null;
    const touchStart = (event: TouchEvent) => {
      if (lookTouchId !== null) return;
      const touch = event.changedTouches[0];
      if (!touch) return;
      lookTouchId = touch.identifier;
      touchPoint.current = { x: touch.clientX, y: touch.clientY };
    };
    const touchMove = (event: TouchEvent) => {
      if (lookTouchId === null || !touchPoint.current) return;
      const touch = Array.from(event.touches).find(candidate => candidate.identifier === lookTouchId);
      if (!touch) return;
      yaw.current -= (touch.clientX - touchPoint.current.x) * 0.004;
      pitch.current = THREE.MathUtils.clamp(pitch.current - (touch.clientY - touchPoint.current.y) * 0.003, -1.15, 1.15);
      touchPoint.current = { x: touch.clientX, y: touch.clientY };
    };
    const touchEnd = (event: TouchEvent) => {
      if (lookTouchId === null) return;
      const stillDown = Array.from(event.touches).some(candidate => candidate.identifier === lookTouchId);
      if (!stillDown) { lookTouchId = null; touchPoint.current = null; }
    };

    window.addEventListener('keydown', down); window.addEventListener('keyup', up); window.addEventListener('keydown', interact);
    window.addEventListener('gamepadconnected', () => setInputMode('gamepad'));
    window.addEventListener('gamepaddisconnected', () => setInputMode('keyboard'));
    document.addEventListener('mousemove', lockedLook);
    canvas.addEventListener('click', requestLock);
    canvas.addEventListener('pointerdown', dragStart); canvas.addEventListener('pointermove', dragLook); canvas.addEventListener('pointerup', dragEnd); canvas.addEventListener('pointercancel', dragEnd);
    canvas.addEventListener('touchstart', touchStart, { passive: true });
    canvas.addEventListener('touchmove', touchMove, { passive: true }); canvas.addEventListener('touchend', touchEnd);
    return () => {
      window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); window.removeEventListener('keydown', interact);
      document.removeEventListener('mousemove', lockedLook);
      canvas.removeEventListener('click', requestLock);
      canvas.removeEventListener('pointerdown', dragStart); canvas.removeEventListener('pointermove', dragLook); canvas.removeEventListener('pointerup', dragEnd); canvas.removeEventListener('pointercancel', dragEnd);
      canvas.removeEventListener('touchstart', touchStart); canvas.removeEventListener('touchmove', touchMove); canvas.removeEventListener('touchend', touchEnd);
    };
  }, [active, gl, onDonationInteract, onNpcInteract]);

  useFrame((_, delta) => {
    if (!active) return;
    camera.rotation.set(pitch.current, yaw.current, 0);
    const input = movement.current;
    const forward = keys.current.KeyW || keys.current.ArrowUp || input.forward;
    const backward = keys.current.KeyS || keys.current.ArrowDown || input.backward;
    const left = keys.current.KeyA || keys.current.ArrowLeft || input.left;
    const right = keys.current.KeyD || keys.current.ArrowRight || input.right;

    const gamepads = navigator.getGamepads?.();
    const gamepad = gamepads?.[0];
    const hasGamepad = Boolean(gamepad && gamepad.connected);
    const axisX = hasGamepad && Math.abs(gamepad.axes[0] ?? 0) > 0.25 ? gamepad.axes[0] : 0;
    const axisZ = hasGamepad && Math.abs(gamepad.axes[1] ?? 0) > 0.25 ? -gamepad.axes[1] : 0;
    const aPressed = Boolean(gamepad?.buttons?.[0]?.pressed);
    const xPressed = Boolean(gamepad?.buttons?.[2]?.pressed);

    if (hasGamepad) {
      setInputMode('gamepad');
      if (aPressed && !lastGamepadButtons.current[0] && grounded.current) {
        jumpVelocity.current = 4.6;
        grounded.current = false;
      }
      if (xPressed && !lastGamepadButtons.current[2]) {
        if (donationFocused.current) { onDonationInteract(); }
        else if (focusedNpc.current) {
          const npc = NPCS.find(item => item.id === focusedNpc.current);
          if (npc) onNpcInteract(npc.category, npc.label);
        }
      }
      lastGamepadButtons.current[0] = aPressed;
      lastGamepadButtons.current[2] = xPressed;
    }

    const z = Number(backward) - Number(forward) + axisZ;
    const x = Number(right) - Number(left) + axisX;
    const sprint = keys.current.ShiftLeft || keys.current.ShiftRight;
    const speed = 3.4 * (sprint ? 1.8 : 1);

    if (x || z) {
      const startX = camera.position.x;
      const startZ = camera.position.z;
      const direction = new THREE.Vector3(x, 0, z).normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw.current);
      const distance = Math.min(delta, 0.05) * speed;
      const nextX = camera.position.x + direction.x * distance;
      const nextZ = camera.position.z + direction.z * distance;

      if (!playerPositionBlocked(nextX, camera.position.z)) camera.position.x = nextX;
      if (!playerPositionBlocked(camera.position.x, nextZ)) camera.position.z = nextZ;
      stepDistance.current += Math.hypot(camera.position.x - startX, camera.position.z - startZ);
      while (stepDistance.current >= 1.1) {
        stepDistance.current -= 1.1;
        onFootstep();
        onStep();
      }
      elapsed.current += delta * 10;
    }

    if (!grounded.current) {
      jumpVelocity.current -= 18 * delta;
      camera.position.y += jumpVelocity.current * delta;
      if (camera.position.y <= 1.65) {
        camera.position.y = 1.65;
        grounded.current = true;
        jumpVelocity.current = 0;
        elapsed.current = 0;
      }
    } else {
      camera.position.y = THREE.MathUtils.lerp(camera.position.y, 1.65 + Math.sin(elapsed.current) * 0.026, delta * 8);
    }
    const nextRoom = roomAt(camera.position.x, camera.position.z);
    if (nextRoom !== currentRoom.current) { currentRoom.current = nextRoom; onRoomChange(nextRoom); }
    const nextExit = camera.position.z < -4.25 && Math.abs(camera.position.x) < 1.25;
    if (nextExit !== atExit.current) { atExit.current = nextExit; onExitChange(nextExit); }

    const donationDistance = Math.hypot(camera.position.x - DONATION_PIG_POSITION[0], camera.position.z - DONATION_PIG_POSITION[2]);
    const nextDonationFocused = donationDistance <= 1.25;
    if (nextDonationFocused !== donationFocused.current) {
      donationFocused.current = nextDonationFocused;
      onDonationFocus(nextDonationFocused);
    }

    positionReportElapsed.current += delta;
    if (positionReportElapsed.current >= 0.1) {
      positionReportElapsed.current = 0;
      onPlayerPosition(camera.position.x, camera.position.z);
    }

    let nearestNpc: NpcDefinition | null = null;
    let nearestDistance = Infinity;
    for (const npc of NPCS) {
      const distance = new THREE.Vector3(npc.position[0], 1.65, npc.position[2]).distanceTo(camera.position);
      if (distance < nearestDistance) {
        nearestDistance = distance;
        nearestNpc = npc;
      }
    }
    const nextFocused = nearestNpc && nearestDistance <= 1.9 ? nearestNpc.id : null;
    if (nextFocused !== focusedNpc.current) {
      focusedNpc.current = nextFocused;
      if (!nextFocused) {
        onNpcFocus(null, null);
      } else {
        const npc = NPCS.find(item => item.id === nextFocused) || null;
        onNpcFocus(npc?.category || null, npc?.label || null);
      }
    }
  });

  return null;
}

interface PinkHaloSceneProps {
  active: boolean;
  products: Product[];
  movement: MutableRefObject<TouchMovement>;
  initialPosition?: { x: number; z: number };
  onRoomChange: (name: string | null) => void;
  onExitChange: (near: boolean) => void;
  onNpcFocus: (category: Product['category'] | 'All' | null, label: string | null) => void;
  onNpcInteract: (category: Product['category'] | 'All', label: string) => void;
  onDonationFocus: (focused: boolean) => void;
  onDonationInteract: () => void;
  onPlayerPosition: (x: number, z: number) => void;
  onFootstep: () => void;
  onStep: () => void;
  onInputModeChange?: (mode: 'keyboard' | 'gamepad') => void;
  inputMode?: 'keyboard' | 'gamepad';
}

function StoreScene(props: PinkHaloSceneProps) {
  return (
    <>
      <color attach="background" args={['#050405']} />
      <fog attach="fog" args={['#12080d', 7, 18]} />
      <ambientLight intensity={0.52} color="#ffe0eb" />
      <hemisphereLight args={['#fff0f4', '#14080e', 0.75]} />
      <spotLight position={[0, 3.15, 2.8]} angle={0.9} penumbra={0.72} intensity={38} color="#ffd6e5" castShadow />
      <pointLight position={[0, 2.15, -4.45]} intensity={18} distance={5} color="#ff5fa2" />
      <pointLight position={[3.55, 1.55, 1.55]} intensity={16} distance={4} color="#ff5fa2" />
      <ShopRoom products={props.products} inputMode={props.inputMode ?? 'keyboard'} />
      <Player
        active={props.active}
        movement={props.movement}
        initialPosition={props.initialPosition}
        onRoomChange={props.onRoomChange}
        onExitChange={props.onExitChange}
        onNpcFocus={props.onNpcFocus}
        onNpcInteract={props.onNpcInteract}
        onDonationFocus={props.onDonationFocus}
        onDonationInteract={props.onDonationInteract}
        onPlayerPosition={props.onPlayerPosition}
        onFootstep={props.onFootstep}
        onStep={props.onStep}
        onInputModeChange={props.onInputModeChange}
      />
    </>
  );
}

export default function PinkHaloScene(props: PinkHaloSceneProps) {
  const gl = useMemo(() => ({ antialias: true, toneMapping: THREE.ACESFilmicToneMapping, toneMappingExposure: 1.22 }), []);
  const startPosition: [number, number, number] = [props.initialPosition?.x ?? 0, 1.65, props.initialPosition?.z ?? 5.4];
  return <Canvas className="world-canvas" camera={{ position: startPosition, fov: 62, near: 0.05, far: 32 }} gl={gl} dpr={[1, 1.6]} shadows><StoreScene {...props} /></Canvas>;
}
